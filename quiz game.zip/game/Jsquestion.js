
let questions = [
    {
    numb: 1,
    question: "How Many days are in a week?",
    answer: "7",
    options: [
      "4",
      "2",
      "1",
      "7"
    ]
  },
    {
    numb: 2,
    question: "how mny alphabets are there in english?",
    answer: "26",
    options: [
      "19",
      "20",
      "26",
      "24"
    ]
  },
    {
    numb: 3,
    question: "how many months in a year?",
    answer: "12",
    options: [
      "7",
      "9",
      "12",
      "10"
    ]
  },
    {
    numb: 4,
    question: "how many sides a triangle has?",
    answer: "3",
    options: [
      "3",
      "4",
      "2",
      "1"
    ]
  },
    {
    numb: 5,
    question: "how many colour are there in a rainbow?",
    answer: "7",
    options: [
      "2",
      "4",
      "7",
      "8"
    ]
  },
       ]
   

